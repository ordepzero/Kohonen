##################
Nibabel data files
##################

``phantom_truncated.REC`` is a copy of ``phantom_EPI_asc_CLEAR_2_1.REC``.

``phantom_truncated.PAR`` is a slightly edited copy of
``phantom_EPI_asc_CLEAR_2_1.PAR``.

``umass_anonymized.PAR`` courtesy of Github user ``cccbauer``, data from the
University of Massachusetts medical school.
